async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with:", deployer.address);
  const Voting = await ethers.getContractFactory("VotingSystems");
  const name = ["Alice", "Bob","Charlie"];
  const voting = await Voting.deploy(names);
  await voting.deployed();
  console.log("Voting deployed to:", voting.address);

  
const fs = require("fs");
  const artifactspaht = "./artifacts/contracts/VotingSystems.sol/VotingSystems.json";
  const abi  = JSON.parse(fs.readFileSync(artifactspaht, "utf8")).abi;
  const jso = { address: voting.address, abi: abi };
  if  (!fs.existsSync("forntend")) fs.mkdirSync("forntend");
   fs.writeFileSync("forntend/contract.json", JSON.stringify(jso, null, 2));
  console.log("Saved frontend/contract.json");
}
main().catch(console => console.error(error)); process.exit(1);