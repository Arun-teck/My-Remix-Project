(async function(){
  // fetch contract info written by deploy script
  const res = await fetch('/contract.json');
  const { address, abi } = await res.json();

  // Connect web3 to localhost Hardhat node inside the Replit VM
  const web3 = new Web3("http://127.0.0.1:8545");
  const contract = new web3.eth.Contract(abi, address);

  const accounts = await web3.eth.getAccounts();
  const defaultAccount = accounts[0];
  document.getElementById('status').innerText = 'Using account: ' + defaultAccount;

  document.getElementById('voteBtn').onclick = async () => {
    const idx = document.getElementById('candidateIndex').value;
    if (idx === "") { alert("Enter candidate index"); return; }
    document.getElementById('status').innerText = 'Sending transaction...';
    try {
      await contract.methods.vote(idx).send({ from: defaultAccount, gas: 3000000 });
      document.getElementById('status').innerText = 'Vote recorded';
    } catch (err) {
      console.error(err);
      document.getElementById('status').innerText = 'Error: ' + (err.message || err);
    }
  };

  document.getElementById('winnerBtn').onclick = async () => {
    try {
      const w = await contract.methods.getWinner().call();
      // w may be an array-like result
      document.getElementById('winner').innerText = `Winner: ${w[0]} with ${w[1]} votes`;
    } catch (err) {
      console.error(err);
      document.getElementById('winner').innerText = 'Error: ' + (err.message || err);
    }
  };

  document.getElementById('candidatesBtn').onclick = async () => {
    try {
      const list = await contract.methods.getCandidates().call();
      document.getElementById('candidates').innerText = JSON.stringify(list, null, 2);
    } catch (err) {
      console.error(err);
      document.getElementById('candidates').innerText = 'Error: ' + (err.message || err);
    }
  };
})();