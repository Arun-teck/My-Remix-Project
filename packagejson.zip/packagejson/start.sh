npx hardhat node --hostname 0.0.0.0 --port 8545 &

sleep 5

npx hardhat run scripts/deploy.js --network localhost

npx http-server frondend -p 3000 -c-1

npm install

chmod +x start.sh

nph run start